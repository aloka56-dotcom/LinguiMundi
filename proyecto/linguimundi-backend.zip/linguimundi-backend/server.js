const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 8080;

app.use(cors());
app.use(express.json());

const usuarios = [
    { id: 1, usuario: 'aloha', contrasena: 'aloha555', idioma: 'Inglés' }
];

const idiomas = [
    { id: 1, nombre: 'Inglés', codigo: 'EN', bandera: '🇬🇧' },
    { id: 2, nombre: 'Francés', codigo: 'FR', bandera: '🇫🇷' },
    { id: 3, nombre: 'Alemán', codigo: 'DE', bandera: '🇩🇪' },
    { id: 4, nombre: 'Italiano', codigo: 'IT', bandera: '🇮🇹' },
    { id: 5, nombre: 'Portugués', codigo: 'PT', bandera: '🇵🇹' }
];

const lecciones = {
    'Inglés': [
        { id: 1, titulo: 'Saludos Básicos', nivel: 'Principiante', duracion: 10 },
        { id: 2, titulo: 'Números 1-10', nivel: 'Principiante', duracion: 8 },
        { id: 3, titulo: 'Colores', nivel: 'Intermedio', duracion: 12 },
        { id: 4, titulo: 'Comida', nivel: 'Intermedio', duracion: 15 },
        { id: 5, titulo: 'Viajes', nivel: 'Avanzado', duracion: 20 }
    ],
    'Francés': [
        { id: 1, titulo: 'Salutations', nivel: 'Principiante', duracion: 10 },
        { id: 2, titulo: 'Nombres 1-10', nivel: 'Principiante', duracion: 8 },
        { id: 3, titulo: 'Couleurs', nivel: 'Intermedio', duracion: 12 },
        { id: 4, titulo: 'Nourriture', nivel: 'Intermedio', duracion: 15 },
        { id: 5, titulo: 'Voyages', nivel: 'Avanzado', duracion: 20 }
    ],
    'Alemán': [
        { id: 1, titulo: 'Begrüßungen', nivel: 'Principiante', duracion: 10 },
        { id: 2, titulo: 'Zahlen 1-10', nivel: 'Principiante', duracion: 8 },
        { id: 3, titulo: 'Farben', nivel: 'Intermedio', duracion: 12 },
        { id: 4, titulo: 'Essen', nivel: 'Intermedio', duracion: 15 },
        { id: 5, titulo: 'Reisen', nivel: 'Avanzado', duracion: 20 }
    ],
    'Italiano': [
        { id: 1, titulo: 'Saluti', nivel: 'Principiante', duracion: 10 },
        { id: 2, titulo: 'Numeri 1-10', nivel: 'Principiante', duracion: 8 },
        { id: 3, titulo: 'Colori', nivel: 'Intermedio', duracion: 12 },
        { id: 4, titulo: 'Cibo', nivel: 'Intermedio', duracion: 15 },
        { id: 5, titulo: 'Viaggi', nivel: 'Avanzado', duracion: 20 }
    ],
    'Portugués': [
        { id: 1, titulo: 'Saudações', nivel: 'Principiante', duracion: 10 },
        { id: 2, titulo: 'Números 1-10', nivel: 'Principiante', duracion: 8 },
        { id: 3, titulo: 'Cores', nivel: 'Intermedio', duracion: 12 },
        { id: 4, titulo: 'Comida', nivel: 'Intermedio', duracion: 15 },
        { id: 5, titulo: 'Viagens', nivel: 'Avanzado', duracion: 20 }
    ]
};

// LOGIN
app.post('/api/auth/login', (req, res) => {
    const { usuario, contrasena } = req.body;
    const encontrado = usuarios.find(u => u.usuario === usuario && u.contrasena === contrasena);

    if (encontrado) {
        res.status(200).json({
            mensaje: 'Autenticación satisfactoria',
            usuario: encontrado.usuario,
            idioma: encontrado.idioma,
            exitoso: true
        });
    } else {
        res.status(401).json({
            mensaje: 'Error en la autenticación',
            exitoso: false
        });
    }
});

// REGISTRO
app.post('/api/auth/registro', (req, res) => {
    const { usuario, contrasena } = req.body;

    if (!usuario || usuario.length < 3) {
        return res.status(400).json({ mensaje: 'Usuario mínimo 3 caracteres', exitoso: false });
    }
    if (!contrasena || contrasena.length < 6) {
        return res.status(400).json({ mensaje: 'Contraseña mínimo 6 caracteres', exitoso: false });
    }
    if (usuarios.find(u => u.usuario === usuario)) {
        return res.status(409).json({ mensaje: 'Usuario ya registrado', exitoso: false });
    }

    const nuevo = { id: usuarios.length + 1, usuario, contrasena, idioma: 'Inglés' };
    usuarios.push(nuevo);

    res.status(201).json({
        mensaje: 'Usuario registrado exitosamente',
        usuario: nuevo.usuario,
        exitoso: true
    });
});

// IDIOMAS
app.get('/api/idiomas', (req, res) => {
    res.status(200).json(idiomas);
});

// LECCIONES
app.get('/api/lecciones/:idioma', (req, res) => {
    const idioma = decodeURIComponent(req.params.idioma);
    const leccionesIdioma = lecciones[idioma];
    if (leccionesIdioma) {
        res.status(200).json(leccionesIdioma);
    } else {
        res.status(404).json({ mensaje: 'Idioma no encontrado', exitoso: false });
    }
});

// CAMBIAR IDIOMA
app.put('/api/usuarios/:usuario/idioma', (req, res) => {
    const { usuario } = req.params;
    const { idioma } = req.body;
    const user = usuarios.find(u => u.usuario === usuario);

    if (!user) return res.status(404).json({ mensaje: 'Usuario no encontrado', exitoso: false });
    if (!idiomas.find(i => i.nombre === idioma)) return res.status(400).json({ mensaje: 'Idioma inválido', exitoso: false });

    user.idioma = idioma;
    res.status(200).json({
        mensaje: 'Idioma actualizado',
        usuario: user.usuario,
        idioma: user.idioma,
        exitoso: true
    });
});

// USUARIOS
app.get('/api/usuarios', (req, res) => {
    res.status(200).json(usuarios.map(u => ({ id: u.id, usuario: u.usuario, idioma: u.idioma })));
});

// SERVIDOR
app.listen(PORT, () => {
    console.log('=========================================');
    console.log('🌐 LinguiMundi API corriendo');
    console.log('📍 http://localhost:8080');
    console.log('=========================================');
    console.log('Endpoints:');
    console.log('  POST   /api/auth/login');
    console.log('  POST   /api/auth/registro');
    console.log('  GET    /api/idiomas');
    console.log('  GET    /api/lecciones/:idioma');
    console.log('  PUT    /api/usuarios/:usuario/idioma');
    console.log('  GET    /api/usuarios');
    console.log('=========================================');
});